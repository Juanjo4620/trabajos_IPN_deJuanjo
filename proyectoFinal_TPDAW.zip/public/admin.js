const token = localStorage.getItem('token');
const role = localStorage.getItem('role');
if (!token || role !== 'admin') { alert('Necesitas iniciar sesión como admin'); location.href = '/'; }

async function fetchComponents() {
  const res = await fetch('/api/components');
  return res.json();
}

async function fetchCategories() { const res = await fetch('/api/categories'); return res.json(); }
let categoriesCache = [];

function authHeaders() { return { 'Content-Type':'application/json', 'Authorization': 'Bearer ' + token }; }

async function loadList() {
  const comps = await fetchComponents();
  const el = document.getElementById('list');
  el.innerHTML = '';
  comps.forEach(c => {
    const d = document.createElement('div'); d.className = 'component';
    // create inline editable fields
    const nameIn = document.createElement('input'); nameIn.value = c.name; nameIn.style.width='40%';
    const priceIn = document.createElement('input'); priceIn.type='number'; priceIn.step='0.01'; priceIn.value = c.price; priceIn.style.width='80px';
    const stockIn = document.createElement('input'); stockIn.type='number'; stockIn.value = c.stock || 0; stockIn.style.width='80px';
    const descIn = document.createElement('input'); descIn.value = c.description || ''; descIn.style.width='40%';
    const catSel = document.createElement('select');
    const emptyOpt = document.createElement('option'); emptyOpt.value=''; emptyOpt.textContent='-- sin categoría --'; catSel.appendChild(emptyOpt);
    categoriesCache.forEach(cat => { const o = document.createElement('option'); o.value = cat.id; o.textContent = cat.name; if (c.category === cat.id) o.selected = true; catSel.appendChild(o); });

    // Display category name
    const categoryName = categoriesCache.find(cat => cat.id === c.category)?.name || '-- sin categoría --';
    const categoryDisplay = document.createElement('span');
    categoryDisplay.textContent = `Categoría: ${categoryName}`;
    categoryDisplay.style.marginLeft = '10px';

    const img = document.createElement('img'); if (c.image) { img.src = c.image; img.className='thumbnail'; } else { img.src='/placeholder.svg'; img.className='thumbnail'; }
    const file = document.createElement('input'); file.type='file'; file.accept='image/*';
    const saveBtn = document.createElement('button'); saveBtn.textContent = 'Guardar';
    saveBtn.onclick = async () => {
      let imagePath = c.image || null;
      if (file.files[0]) {
        const fd = new FormData(); fd.append('image', file.files[0]);
        console.log('Uploading image:', file.files[0].name); // Debugging log
        const up = await fetch('/api/upload', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token }, body: fd });
        if (up.ok) {
          const j = await up.json();
          imagePath = j.path;
          console.log('Image uploaded successfully:', imagePath); // Debugging log
        } else {
          const errorText = await up.text();
          console.error('Error uploading image:', errorText); // Debugging log
          alert('Error subiendo imagen');
          return;
        }
      }
      const payload = { name: nameIn.value, price: Number(priceIn.value), stock: Number(stockIn.value), description: descIn.value, category: catSel.value || null, image: imagePath };
      const res = await fetch('/api/components/' + c.id, { method: 'PUT', headers: authHeaders(), body: JSON.stringify(payload) });
      if (res.ok) { showMsg('Guardado', 'success'); loadList(); }
      else {
        const err = await res.json().catch(()=>({ error: 'unknown' }));
        showMsg('Error al guardar: ' + (err.error || err.details || res.status), 'error');
      }
    };
    const delBtn = document.createElement('button'); delBtn.textContent = 'Eliminar'; delBtn.style.marginLeft='8px';
    delBtn.onclick = async () => {
      if (!confirm('Eliminar componente "' + c.name + '" ?')) return;
      const res = await fetch('/api/components/' + c.id, { method: 'DELETE', headers: authHeaders() });
      if (res.ok) { showMsg('Eliminado', 'success'); loadList(); }
      else {
        const e = await res.json().catch(()=>({ error: 'unknown' }));
        showMsg('Error al eliminar: ' + (e.error || e.details || res.status), 'error');
      }
    };
    d.appendChild(nameIn);
    d.appendChild(priceIn);
    d.appendChild(stockIn);
    d.appendChild(catSel);
    d.appendChild(descIn);
    d.appendChild(categoryDisplay);
    if (c.image) d.appendChild(img);
    d.appendChild(file);
    d.appendChild(saveBtn);
    d.appendChild(delBtn);
    el.appendChild(d);
  });
}

document.getElementById('btnAdd').addEventListener('click', async () => {
  const name = document.getElementById('name').value;
  const price = document.getElementById('price').value;
  const stock = document.getElementById('stock').value;
  const description = document.getElementById('description').value;
  const category = document.getElementById('categorySelect').value || null;
  const file = document.getElementById('imageFile').files[0];
  let imagePath = null;
  if (file) {
    const fd = new FormData(); fd.append('image', file);
    const up = await fetch('/api/upload', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token }, body: fd });
    if (up.ok) { const j = await up.json(); imagePath = j.path; } else { alert('Error subiendo imagen'); return; }
  }
  const res = await fetch('/api/components', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ name, price, stock, description, category, image: imagePath }) });
  if (res.ok) { alert('Agregado'); loadList(); } else alert('Error al agregar');
});

async function populateCategories() {
  const cats = await fetchCategories();
  categoriesCache = cats || [];
  const sel = document.getElementById('categorySelect'); sel.innerHTML = '<option value="">-- categoría --</option>';
  cats.forEach(c => { const o = document.createElement('option'); o.value = c.id; o.textContent = c.name; sel.appendChild(o); });
  renderCategoriesList();
}

loadList(); populateCategories();

// Category management
async function renderCategoriesList() {
  const el = document.getElementById('categoriesList'); el.innerHTML = '';
  categoriesCache.forEach(c => {
    const div = document.createElement('div'); div.style.display='flex'; div.style.alignItems='center';
    const name = document.createElement('span'); name.textContent = c.name; name.style.flex='1';
    const edit = document.createElement('button'); edit.textContent='Editar'; edit.onclick = async () => {
      const newName = prompt('Nuevo nombre', c.name);
      if (newName == null) return;
      const res = await fetch('/api/categories/' + c.id, { method: 'PUT', headers: authHeaders(), body: JSON.stringify({ name: newName }) });
      if (res.ok) { await populateCategories(); loadList(); } else alert('Error');
    };
    div.appendChild(name); div.appendChild(edit); el.appendChild(div);
  });
}

document.getElementById('btnAddCategory').addEventListener('click', async () => {
  const name = document.getElementById('newCategoryName').value;
  if (!name) return alert('Nombre requerido');
  const res = await fetch('/api/categories', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ name }) });
  if (res.ok) { document.getElementById('newCategoryName').value=''; await populateCategories(); loadList(); showMsg('Categoría agregada','success'); }
  else { const e = await res.json().catch(()=>({ error:'unknown' })); showMsg('Error agregando categoría: '+(e.error||e.details||res.status),'error'); }
});

function showMsg(text, type) {
  const m = document.getElementById('adminMessage'); m.style.display='block'; m.textContent = text; m.className = 'message ' + (type || 'info');
  setTimeout(()=>{ m.style.display='none'; }, 4000);
}
