const token = localStorage.getItem('token');
if (!token) { alert('Necesitas iniciar sesión'); location.href = '/'; }

async function loadComponents() {
  const res = await fetch('/api/components');
  return res.json();
}

async function loadCategories() { 
  try {
    const res = await fetch('/api/categories');
    if (!res.ok) {
      console.error('Failed to fetch categories:', res.status, await res.text());
      return [];
    }
    return res.json();
  } catch (error) {
    console.error('Error loading categories:', error);
    return [];
  }
}
let awaitCategories = [];

function authHeaders() { 
  return { 'Content-Type':'application/json', 'Authorization': 'Bearer ' + token }; 
}

async function renderList() {
  try {
    const comps = await loadComponents();
    const el = document.getElementById('list'); el.innerHTML = '';
    const filter = document.getElementById('filterCat').value || '';
    comps.forEach(c => {
      if (filter && c.category !== filter) return;
      const card = document.createElement('div'); card.className = 'card';
      const img = document.createElement('img'); img.className = 'card-img';
      img.src = c.image || '/placeholder.svg';
      img.onerror = () => console.error('Image failed to load:', img.src); // Debugging log
      const name = document.createElement('div'); name.className = 'card-name'; name.textContent = c.name;
      const price = document.createElement('div'); price.className = 'card-price'; price.textContent = '$' + c.price;
      const catName = (awaitCategories.find(x=>x.id===c.category) || {}).name || '';
      const catSmall = document.createElement('div'); catSmall.className = 'card-cat'; catSmall.textContent = catName;
      const actions = document.createElement('div'); actions.className='card-actions';
      const qty = document.createElement('input'); qty.type='number'; qty.value=1; qty.min=1; qty.style.width='60px';
      const btn = document.createElement('button'); btn.textContent='Agregar';
      btn.onclick = async () => {
        const q = Number(qty.value || 1);
        const res = await fetch('/api/cart/add', { method: 'POST', headers: authHeaders(), body: JSON.stringify({ componentId: c.id, quantity: q }) });
        if (res.ok) { alert('Agregado'); loadCart(); } else { const e = await res.json().catch(()=>({})); alert('Error: '+(e.error||e.details||res.status)); }
      };
      actions.appendChild(qty); actions.appendChild(btn);
      card.appendChild(img); card.appendChild(name); card.appendChild(price); card.appendChild(catSmall); card.appendChild(actions);
      el.appendChild(card);
    });
  } catch (error) {
    console.error('Error rendering list:', error);
  }
}

async function loadCart() {
  const res = await fetch('/api/cart', { headers: authHeaders() });
  const cart = await res.json();
  const el = document.getElementById('cart'); el.innerHTML = '';
  if (!cart || cart.length===0) { el.textContent = 'Carrito vacío'; return; }
  cart.forEach(i => {
    const d = document.createElement('div'); d.className='component';
    d.innerHTML = `<div>${i.componentId} — cantidad: ${i.quantity}</div>`;
    const del = document.createElement('button'); del.textContent='Quitar';
    del.onclick = async () => { await fetch('/api/cart/' + i.componentId, { method: 'DELETE', headers: authHeaders() }); loadCart(); };
    d.appendChild(del); el.appendChild(d);
  });
}

document.getElementById('btnExport').addEventListener('click', async () => {
  const res = await fetch('/api/cart', { headers: authHeaders() });
  if (!res.ok) {
    alert('Error al obtener el carrito');
    return;
  }
  const cart = await res.json();
  if (!cart || cart.length === 0) {
    alert('El carrito está vacío');
    return;
  }

  let cartDetails = 'Resumen del pedido:\n';
  cart.forEach((item) => {
    cartDetails += `Componente: ${item.componentId}, Cantidad: ${item.quantity}\n`;
  });
  cartDetails += '\nTotal: Por calcular con el vendedor';

  alert(cartDetails);
  // Aquí se puede agregar lógica para enviar el carrito al vendedor, por ejemplo, por correo o API.
});

async function populateCategories() {
  const cats = await loadCategories();
  awaitCategories = cats || [];
  const sel = document.getElementById('filterCat');
  cats.forEach(c => { const o = document.createElement('option'); o.value = c.id; o.textContent = c.name; sel.appendChild(o); });
  sel.addEventListener('change', renderList);
}

populateCategories();
renderList(); loadCart();
