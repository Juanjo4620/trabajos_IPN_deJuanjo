async function login() {
  const btn = document.getElementById('btnLogin');
  btn.disabled = true;
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  if (!username || !password) { alert('Usuario y contraseña requeridos'); btn.disabled = false; return; }
  const res = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify({ username, password }) });
  const data = await res.json();
  if (res.ok) {
    localStorage.setItem('token', data.token);
    localStorage.setItem('role', data.role);
    localStorage.setItem('username', data.username);
    const linksEl = document.getElementById('links');
    if (linksEl) linksEl.style.display = 'block';
    // redirect to the appropriate area
    if (data.role === 'admin') window.location.href = '/admin.html';
    else window.location.href = '/user.html';
  } else {
    alert(data.error || 'Error');
  }
  btn.disabled = false;
}

document.getElementById('btnLogin').addEventListener('click', login);

// show links if already logged
if (localStorage.getItem('token')) document.getElementById('links').style.display = 'block';

// register
async function register() {
  const btn = document.getElementById('btnRegister');
  btn.disabled = true;
  const username = document.getElementById('regUsername').value.trim();
  const password = document.getElementById('regPassword').value;
  if (!username || !password) { alert('Usuario y contraseña requeridos'); btn.disabled = false; return; }
  const res = await fetch('/api/register', { method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify({ username, password }) });
  const data = await res.json();
  if (res.ok) {
    localStorage.setItem('token', data.token);
    localStorage.setItem('role', data.role);
    localStorage.setItem('username', data.username);
    const linksEl = document.getElementById('links');
    if (linksEl) linksEl.style.display = 'block';
    if (data.role === 'admin') window.location.href = '/admin.html';
    else window.location.href = '/user.html';
  } else {
    alert(data.error || 'Error registrando');
  }
  btn.disabled = false;
}

document.getElementById('btnRegister').addEventListener('click', register);
